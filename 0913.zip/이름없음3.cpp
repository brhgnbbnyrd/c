#include<stdio.h>

int main()
{
	int grade = 6;
	int class = 3;
//	int number = 22;
//
	printf("%d�г�",grade);
	printf("%d��",class);
	printf("%d��"); 
	return 0;
}
