#include<stdio.h>

int main()
{
	int a;
	float f1;
	char ch;

	
	a = 15;
	f1 = 123.456;
	ch = 'A';
	printf("%d\n", a);
	printf("%.3f\n", f1);
	printf("%c\n", ch);
	return 0;
} 
