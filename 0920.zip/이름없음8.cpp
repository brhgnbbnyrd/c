#include<stdio.h>

int main()
{
int cm;
int mm;

cm= 32.54*100;
mm=32.54*1000;
printf("%dcm,%dmm",cm,mm);
return 0;
}
